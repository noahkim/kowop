<?php

class PaymentController extends Controller
{
    /**
     * @return array action filters
     */
    public function filters()
    {
        return array(
            'accessControl', // perform access control for CRUD operations
            'postOnly + delete', // we only allow deletion via POST request
        );
    }

    /**
     * Specifies the access control rules.
     * This method is used by the 'accessControl' filter.
     * @return array access control rules
     */
    public function accessRules()
    {
        return array(
            array('allow',
                'users' => array('@'),
            ),
            array('deny', // deny all users
                'users' => array('*'),
            ),
        );
    }

    public function actionGetCards()
    {
        Yii::import('application.extensions.vendor.autoload', true);

        Httpful\Bootstrap::init();
        Balanced\Bootstrap::init();

        $user = $this->getUser();

        $cards = array();

        foreach($user->creditCards as $card)
        {
            $cards[] = $card;
        }

        echo CJSON::encode($cards);
    }

    public function actionAddCard()
    {
        $isCreated = false;

        if(isset($_POST['data']))
        {
            $dataString = $_POST['data'];
            $data = json_decode($dataString);

            $uri = $data->uri;

            $card = new CreditCard();
            $card->User_ID = $this->getUser()->User_ID;
            $card->URI = $uri;

            $isCreated = $card->save();
        }

        if($isCreated)
        {
            echo 'Success';
        }
        else
        {
            echo 'Error';
        }
    }

    /**
     * Creates a new model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     */
    public function actionCreate()
    {
    }

    /**
     * Updates a particular model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id the ID of the model to be updated
     */
    public function actionUpdate($id)
    {
    }

    /**
     * Deletes a particular model.
     * If deletion is successful, the browser will be redirected to the 'admin' page.
     * @param integer $id the ID of the model to be deleted
     */
    public function actionDelete($id)
    {
    }

    /**
     * Lists all models.
     */
    public function actionIndex()
    {
        echo "hmm";
    }

    /**
     * Returns the data model based on the primary key given in the GET variable.
     * If the data model is not found, an HTTP exception will be raised.
     * @param integer the ID of the model to be loaded
     */
    public function loadModel($id)
    {
        $model = Payment::model()->findByPk($id);
        if ($model === null)
        {
            throw new CHttpException(404, 'The requested page does not exist.');
        }

        return $model;
    }

    public function getUser()
    {
        $user = User::model()->findByPk(Yii::app()->user->id);
        return $user;
    }
}
