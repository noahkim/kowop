<!---------- right column--------------->
<div class="nine columns accountInformation">
    <h1>Payment Information</h1>

    <dl class="tabs">
        <dd class="active"><a href="#simple1">My Credit Card information</a></dd>
        <dd><a href="#simple2">Receving Payments (my bank account information)</a></dd>
    </dl>

    <ul class="tabs-content">
        <li class="active" id="simple1Tab">
            <h4>Saved credit cards</h4>

            <div id="savedCards"></div>

            <!--<p><input type="checkbox">Visa ending in ***********3254</p>

            <p><input type="checkbox">Visa ending in ***********3254</p>-->

            <a href="#" class="button large">Remove selected cards</a>

            <form action="#" method="POST" id="credit-card-form">
                <h4>Enter a new credit card</h4>

                <div class="row">
                    <div class="eight columns">
                        <label>Card Number</label>

                        <input type="text"
                               value="4111111111111111"
                               autocomplete="off"
                               placeholder="Card Number"
                               class="cc-number">
                    </div>
                    <div class="four columns">
                        <label>Security Code (CSC)</label>

                        <input type="text" value="123" autocomplete="off" placeholder="CSC" class="cc-csc">
                    </div>
                </div>

                <div class="row">
                    <div class="six columns">
                        <label>Exp. Month</label>

                        <select class="cc-em">
                            <option value='1'>January</option>
                            <option value='2'>February</option>
                            <option value='3'>March</option>
                            <option value='4'>April</option>
                            <option value='5'>May</option>
                            <option value='6' selected>June</option>
                            <option value='7'>July</option>
                            <option value='8'>August</option>
                            <option value='9'>September</option>
                            <option value='10'>October</option>
                            <option value='11'>November</option>
                            <option value='12'>December</option>
                        </select>
                    </div>
                    <div class="six columns">
                        <label>Exp. Year</label>

                        <select class="cc-ey">
                            <option selected>2013</option>
                            <option>2014</option>
                            <option>2015</option>
                            <option>2016</option>
                            <option>2017</option>
                            <option>2018</option>
                            <option>2019</option>
                            <option>2020</option>
                            <option>2021</option>
                            <option>2022</option>
                        </select>
                    </div>
                </div>

                <!--<div id="cardType" style="height: 75px;"></div>-->

                <a class="button large" href="#" id="saveCard">Save</a>
            </form>
        </li>

        <li id="simple2Tab">
            <form action="#" method="POST" id="bank-account-form">
                <label>Account Holder's Name</label> <input type="text"
                                                            autocomplete="off"
                                                            placeholder="Bank Account Holder's name"
                                                            class="ba-name">

                <label>Routing Number</label> <input type="text"
                                                     autocomplete="off"
                                                     placeholder="Routing Number"
                                                     class="ba-rn">

                <label>Account Number</label> <input type="text"
                                                     autocomplete="off"
                                                     placeholder="Account Number"
                                                     class="ba-an">

                <label>Account Type</label> <select>
                <option value='' disabled selected style='display:none;'>
                    Select Account Type
                </option>
                <option value="checking">CHECKING</option>
                <option value="savings">SAVINGS</option>
            </select>

                <button type="submit" class="button large">
                    Save
                </button>
            </form>
        </li>
    </ul>

</div>
<!---------- end right column ----------->

<script type="text/javascript" src="https://js.balancedpayments.com/v1/balanced.js"></script>
<script>
    $(document).ready(function ()
    {
        balanced.init('<?php echo Yii::app()->params["balancedMarketPlaceURI"]; ?>');

        loadCards();

        /*        $('.cc-number').keypress(function ()
                {
                    var cardType = balanced.card.cardType($('.cc-number').val());
                    if (cardType != null)
                    {
                        $('#cardType').empty();

                        var imageCardType = cardType.toLowerCase().replace(' ', '');
                        var imageLink = "<?php echo Yii::app()->params['siteBase']; ?>/images/" + imageCardType + '.gif';

                $('#cardType').append('<img src="' + imageLink + '" alt="' + cardType + '" title="' + cardType + '" />');
            }
        });*/

        $('#saveCard').click(function (e)
        {
            e.preventDefault();

            var expiryYear = $('.cc-ey').val();
            if (expiryYear.length == 2)
            {
                expiryYear = "20" + expiryYear;
            }

            var card = {
                "card_number"     :$('.cc-number').val(),
                "security_code"   :$('.cc-csc').val(),
                "expiration_month":$('.cc-em').val(),
                "expiration_year" :expiryYear
            };

            balanced.card.create(card, cardCallbackHandler);
        });
    });


    function cardCallbackHandler(response)
    {
        switch (response.status)
        {
            case 201:
                // WOO HOO!
                // response.data.uri == uri of the card or bank account resource
                console.log(response.data.uri);

                var dataString = JSON.stringify(response.data);

                $.ajax({
                    type   :'post',
                    url    :"<?php echo Yii::app()->createAbsoluteUrl('/payment/addCard'); ?>",
                    data   :{ data:dataString },
                    success:function (results)
                    {
                        loadCards();
                    }
                });
                break;
            case 400:
                // missing field - check response.error for details
                console.log(response.error);
                break;
            case 402:
                // we couldn't authorize the buyer's credit card
                // check response.error for details
                console.log(response.error);
                break
            case 404:
                // your marketplace URI is incorrect
                console.log(response.error);
                break;
            case 500:
                // Balanced did something bad, please retry the request
                console.log(response.error);
                break;
        }
    }

    function loadCards()
    {
        $.ajax({
            type   :'get',
            url    :"<?php echo Yii::app()->createAbsoluteUrl('/payment/getcards'); ?>",
            success:function (results)
            {
                var cards = JSON.parse(results);

                $('#savedCards').empty();

                for (var i in cards)
                {
                    $('#savedCards').append('<p><input type="checkbox">Visa ending in ***********3254</p>');
                }
            }
        })
    }
</script>