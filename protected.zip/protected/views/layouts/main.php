<?php $this->beginContent('//layouts/mainOuter'); ?>

<?php echo $this->renderPartial('/site/_headernav'); ?>

<?php echo $content; ?>

<?php $this->endContent(); ?>
