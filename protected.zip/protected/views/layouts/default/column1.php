<?php /* @var $this Controller */ ?>
<?php $this->beginContent('//layouts/default/main'); ?>
<div id="content">
	<?php echo $content; ?>
</div><!-- content -->
<?php $this->endContent(); ?>